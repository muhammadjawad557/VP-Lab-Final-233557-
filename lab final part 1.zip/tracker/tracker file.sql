-- Switch to the 'tracker' database
USE tracker;

-- Create the student table
CREATE TABLE studnt (
    Id INT PRIMARY KEY IDENTITY(1,1),  -- Auto-increment ID
    Name NVARCHAR(100) NOT NULL,        -- Student's Name
    Grade NVARCHAR(10) NOT NULL,        -- Student's Grade
    Subject NVARCHAR(100) NOT NULL,     -- Subject Name
    Marks INT NOT NULL,                 -- Marks obtained by the student
    AttendancePercentage FLOAT NOT NULL -- Student's Attendance Percentage
);

-- Insert some sample data into the student table
INSERT INTO studnt(Name, Grade, Subject, Marks, AttendancePercentage)
VALUES 
('Zaeem Tahir', 'A', 'Math', 95, 85.5),
('Babar Azam', 'B', 'Science', 88, 90.0),
('Ihtisham Snake', 'A', 'English', 92, 87.0),
('Rao Zohaib', 'C', 'History', 70, 80.0);

-- Add a new student (Functionality 1: Add Student)
INSERT INTO studnt (Name, Grade, Subject, Marks, AttendancePercentage)
VALUES ('Michael Davis', 'A', 'Physics', 91, 95.0);

-- Edit an existing student's details (Functionality 2: Edit Student)
UPDATE studnt
SET Name = 'Zaeem Tahir Updated', 
    Grade = 'B', 
    Subject = 'Physics', 
    Marks = 85, 
    AttendancePercentage = 90.0
WHERE Id = 1;

-- Delete a student by Id (Functionality 3: Delete Student)
DELETE FROM studnt WHERE Id = 2;
